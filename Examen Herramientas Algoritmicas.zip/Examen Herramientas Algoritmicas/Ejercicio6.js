function cuentaRegresiva(numInicial){
    let arrayCuentaRegresiva = [];
    for (let i = 0; i < numInicial; i++){
        arrayCuentaRegresiva.push(numInicial-i);
    }
    console.log(arrayCuentaRegresiva)
}

let numInicial =10;
cuentaRegresiva(numInicial)

